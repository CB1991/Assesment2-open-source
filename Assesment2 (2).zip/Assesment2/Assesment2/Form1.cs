﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assesment2
{
    public partial class Form1 : Form
    {   // Declare Array size 
        const int ARRAY_SIZE = 5;
        double[] num_array = new double[ARRAY_SIZE];
        int cnt = 0;
        double dbl_UofM, dbl_Convert; 


        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Save_Click(object sender, EventArgs e)
        { // Limit Count number
            for (int i = 0; i < cnt; i++)   // i<cnt; or i<num_Size
            {
                lst_Inputs.Items.Add(num_array[i]);
            }
        }

        private void btn_Convert_Click(object sender, EventArgs e)
        {
             
        }

        private void btn_Display_Click(object sender, EventArgs e)
        {
            double myNum;

            if (cnt < ARRAY_SIZE)
            {
                myNum = Convert.ToDouble(textBox1.Text);
                num_array[cnt] = myNum;
                cnt++;
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("you cannot enter more than 6 numbers");
            }
        }

        private void lst_Inputs_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_M_TO_Feet_Click(object sender, EventArgs e)
        {
            const double M_TO_Feet = 3.3937;

            // validate user entry and convert to a double

            if (!double.TryParse(textBox1.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                textBox1.Clear();
                textBox1.Focus();

            }
            else
            {
                dbl_Convert = dbl_UofM * M_TO_Feet;
                lst_Inputs.Items.Add(textBox1.Text + "\t" + " Meters");
                

                lst_converts.Items.Add(dbl_Convert.ToString() + " Feet");
                

            }
        }

        private void btn_C_To_Fahrenheit_Click(object sender, EventArgs e)
        {
            const double C_To_Fahrenheit = 1.8;

            // validate user entry and convert to a double

            if (!double.TryParse(textBox1.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                textBox1.Clear();
                textBox1.Focus();

            }
            else
            {
                dbl_Convert = (dbl_UofM - 32)/ C_To_Fahrenheit ;
                lst_Inputs.Items.Add(textBox1.Text + "\t" + "Ceultis");


                lst_converts.Items.Add(dbl_Convert.ToString() + " F");
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_C_TO_Feet_Click(object sender, EventArgs e)
        {
            {
                const double C_To_Feet = 0.0328084;

                // validate user entry and convert to a double

                if (!double.TryParse(textBox1.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    textBox1.Clear();
                    textBox1.Focus();

                }
                else
                {
                    dbl_Convert = (dbl_UofM - 32) / C_To_Feet   ;
                    lst_Inputs.Items.Add(textBox1.Text + "\t" + "C");


                    lst_converts.Items.Add(dbl_Convert.ToString() + "Feet");
                }
            }
        }

        private void btn_K_TO_Miles_Click(object sender, EventArgs e)
        {
            {
                const double K_TO_Miles = 0.621371;

                // validate user entry and convert to a double

                if (!double.TryParse(textBox1.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    textBox1.Clear();
                    textBox1.Focus();

                }
                else
                {
                    dbl_Convert = dbl_UofM * K_TO_Miles;
                    lst_Inputs.Items.Add(textBox1.Text + "\t" + "Km");


                    lst_converts.Items.Add(dbl_Convert.ToString()+"Miles");


                }
            }
        }

        private void btn_C_TO_Inches_Click(object sender, EventArgs e)
        {
            {
                const double C_TO_Inches = 0.3937;

                // validate user entry and convert to a double

                if (!double.TryParse(textBox1.Text, out dbl_UofM))
                {
                    MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                    textBox1.Clear();
                    textBox1.Focus();

                }
                else
                {
                    dbl_Convert = dbl_UofM * C_TO_Inches;
                    lst_Inputs.Items.Add(textBox1.Text  + " cm");


                    lst_converts.Items.Add(dbl_Convert.ToString() + " Inches");


                }
            }
        }
    }
}

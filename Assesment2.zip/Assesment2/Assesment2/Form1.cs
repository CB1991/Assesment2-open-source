﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assesment2
{
    public partial class Form1 : Form
    {   // Declare Array size 
        const int ARRAY_SIZE = 5;
        double[] num_array = new double[ARRAY_SIZE];
        int cnt = 0;
        double dbl_UofM, dbl_Convert;


        public Form1()
        {
            InitializeComponent();
        }

        private void btn_M_TO_Feet_Click(object sender, EventArgs e)
        { // Construct M_TO_Feet
            const double M_TO_Feet = 3.3937;

            // 
                for (int i = 0; i < cnt; i++)   // i<cnt; or i<num_Size
                {
                    dbl_Convert = num_array[i] * M_TO_Feet;
                    lst_Inputs.Items.Add(num_array[i] + " M");
                    lst_converts.Items.Add(dbl_Convert.ToString() + " Feet");
                }
            


        }

        private void btn_C_To_Fahrenheit_Click(object sender, EventArgs e)
        {
            const double C_To_Fahrenheit = 1.8;

            // validate user entry and convert to a double

          
                for (int i = 0; i < cnt; i++)   // i<cnt; or i<num_Size
                {
                    dbl_Convert = (num_array[i] - 32) / C_To_Fahrenheit;
                    lst_Inputs.Items.Add(num_array[i] + "\t" + "Ceultis");


                    lst_converts.Items.Add(dbl_Convert.ToString() + " F");
                }
            }
        



        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_C_TO_Feet_Click(object sender, EventArgs e)
        {
            {
                const double C_To_Feet = 0.0328084;

                // validate user entry and convert to a double

               
                    for (int i = 0; i < cnt; i++)
                    {
                        dbl_Convert = num_array[i] / C_To_Feet;
                        lst_Inputs.Items.Add(num_array[i] + "\t" + "C");


                        lst_converts.Items.Add(dbl_Convert.ToString() + "Feet");
                    }
                    
            }
        }

        private void btn_K_TO_Miles_Click(object sender, EventArgs e)
        {
            {
                const double K_TO_Miles = 0.621371;

                // validate user entry and convert to a double

               
                    for (int i = 0; i < cnt; i++)   // i<cnt; or i<num_Size
                    {
                        dbl_Convert = num_array[i] * K_TO_Miles; ;
                        lst_Inputs.Items.Add(num_array[i] + "\t" + "Km");
                        lst_converts.Items.Add(dbl_Convert.ToString() + "Miles");
                    }
                
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            {
                lst_Inputs.Items.Clear();
                lst_converts.Items.Clear();
                cnt = 0;
             
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            double myNum;
            
                  if (!double.TryParse(txt_Input.Text, out dbl_UofM))
            {
                MessageBox.Show("A numeric must be entered. Please re-enter the value.");
                txt_Input.Clear();
                txt_Input.Focus();
                
            }
            else
            {
                if (cnt < ARRAY_SIZE)
                {
                    myNum = Convert.ToDouble(txt_Input.Text);
                    num_array[cnt] = myNum;
                    cnt++;
                    txt_Input.Clear();
                }
                else
                {
                    MessageBox.Show("you cannot enter more than 5 numbers");
                }
            }
        }

        private void lst_Inputs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        

        private void btn_C_TO_Inches_Click(object sender, EventArgs e)
        {
            const double C_TO_Inches = 0.3937;
            
                for (int i = 0; i < cnt; i++)   // i<cnt; or i<num_Size
                {
                    dbl_Convert = num_array[i] * C_TO_Inches;
                    lst_Inputs.Items.Add(num_array[i] + " cm");
                    lst_converts.Items.Add(dbl_Convert.ToString() + " Inches");
                }
            



        }
    }
}

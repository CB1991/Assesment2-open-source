﻿namespace Assesment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_C_TO_Inches = new System.Windows.Forms.Button();
            this.btn_M_TO_Feet = new System.Windows.Forms.Button();
            this.btn_C_To_Fahrenheit = new System.Windows.Forms.Button();
            this.btn_C_TO_Feet = new System.Windows.Forms.Button();
            this.btn_K_TO_Miles = new System.Windows.Forms.Button();
            this.txt_Input = new System.Windows.Forms.TextBox();
            this.lst_Inputs = new System.Windows.Forms.ListBox();
            this.lst_converts = new System.Windows.Forms.ListBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lbl_measure1 = new System.Windows.Forms.Label();
            this.lbl_measure2 = new System.Windows.Forms.Label();
            this.lbl_measure3 = new System.Windows.Forms.Label();
            this.lbl_measure4 = new System.Windows.Forms.Label();
            this.lbl_measure5 = new System.Windows.Forms.Label();
            this.lbl_measure6 = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Exit
            // 
            this.btn_Exit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Exit.Location = new System.Drawing.Point(217, 524);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 24);
            this.btn_Exit.TabIndex = 2;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_C_TO_Inches
            // 
            this.btn_C_TO_Inches.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_C_TO_Inches.Location = new System.Drawing.Point(47, 185);
            this.btn_C_TO_Inches.Name = "btn_C_TO_Inches";
            this.btn_C_TO_Inches.Size = new System.Drawing.Size(237, 31);
            this.btn_C_TO_Inches.TabIndex = 3;
            this.btn_C_TO_Inches.Text = "Centimetres to Inches";
            this.btn_C_TO_Inches.UseVisualStyleBackColor = true;
            this.btn_C_TO_Inches.Click += new System.EventHandler(this.btn_C_TO_Inches_Click);
            // 
            // btn_M_TO_Feet
            // 
            this.btn_M_TO_Feet.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_M_TO_Feet.Location = new System.Drawing.Point(46, 220);
            this.btn_M_TO_Feet.Name = "btn_M_TO_Feet";
            this.btn_M_TO_Feet.Size = new System.Drawing.Size(238, 30);
            this.btn_M_TO_Feet.TabIndex = 4;
            this.btn_M_TO_Feet.Text = "Meters to Feet";
            this.btn_M_TO_Feet.UseVisualStyleBackColor = true;
            this.btn_M_TO_Feet.Click += new System.EventHandler(this.btn_M_TO_Feet_Click);
            // 
            // btn_C_To_Fahrenheit
            // 
            this.btn_C_To_Fahrenheit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_C_To_Fahrenheit.Location = new System.Drawing.Point(46, 253);
            this.btn_C_To_Fahrenheit.Name = "btn_C_To_Fahrenheit";
            this.btn_C_To_Fahrenheit.Size = new System.Drawing.Size(238, 33);
            this.btn_C_To_Fahrenheit.TabIndex = 5;
            this.btn_C_To_Fahrenheit.Text = "Celsius to Fahrenheit";
            this.btn_C_To_Fahrenheit.UseVisualStyleBackColor = true;
            this.btn_C_To_Fahrenheit.Click += new System.EventHandler(this.btn_C_To_Fahrenheit_Click);
            // 
            // btn_C_TO_Feet
            // 
            this.btn_C_TO_Feet.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_C_TO_Feet.Location = new System.Drawing.Point(44, 292);
            this.btn_C_TO_Feet.Name = "btn_C_TO_Feet";
            this.btn_C_TO_Feet.Size = new System.Drawing.Size(240, 31);
            this.btn_C_TO_Feet.TabIndex = 6;
            this.btn_C_TO_Feet.Text = "Centimetres to Feet";
            this.btn_C_TO_Feet.UseVisualStyleBackColor = true;
            this.btn_C_TO_Feet.Click += new System.EventHandler(this.btn_C_TO_Feet_Click);
            // 
            // btn_K_TO_Miles
            // 
            this.btn_K_TO_Miles.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_K_TO_Miles.Location = new System.Drawing.Point(44, 329);
            this.btn_K_TO_Miles.Name = "btn_K_TO_Miles";
            this.btn_K_TO_Miles.Size = new System.Drawing.Size(240, 36);
            this.btn_K_TO_Miles.TabIndex = 7;
            this.btn_K_TO_Miles.Text = " Kilometres to Miles";
            this.btn_K_TO_Miles.UseVisualStyleBackColor = true;
            this.btn_K_TO_Miles.Click += new System.EventHandler(this.btn_K_TO_Miles_Click);
            // 
            // txt_Input
            // 
            this.txt_Input.Location = new System.Drawing.Point(44, 61);
            this.txt_Input.Name = "txt_Input";
            this.txt_Input.Size = new System.Drawing.Size(100, 20);
            this.txt_Input.TabIndex = 19;
            // 
            // lst_Inputs
            // 
            this.lst_Inputs.FormattingEnabled = true;
            this.lst_Inputs.Location = new System.Drawing.Point(46, 96);
            this.lst_Inputs.Name = "lst_Inputs";
            this.lst_Inputs.Size = new System.Drawing.Size(238, 82);
            this.lst_Inputs.TabIndex = 9;
            this.lst_Inputs.SelectedIndexChanged += new System.EventHandler(this.lst_Inputs_SelectedIndexChanged);
            // 
            // lst_converts
            // 
            this.lst_converts.FormattingEnabled = true;
            this.lst_converts.Location = new System.Drawing.Point(46, 371);
            this.lst_converts.Name = "lst_converts";
            this.lst_converts.Size = new System.Drawing.Size(238, 134);
            this.lst_converts.TabIndex = 10;
            // 
            // btn_Save
            // 
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Save.Location = new System.Drawing.Point(146, 60);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(71, 27);
            this.btn_Save.TabIndex = 11;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // lbl_measure1
            // 
            this.lbl_measure1.AutoSize = true;
            this.lbl_measure1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_measure1.Location = new System.Drawing.Point(110, 237);
            this.lbl_measure1.Name = "lbl_measure1";
            this.lbl_measure1.Size = new System.Drawing.Size(0, 13);
            this.lbl_measure1.TabIndex = 12;
            // 
            // lbl_measure2
            // 
            this.lbl_measure2.AutoSize = true;
            this.lbl_measure2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_measure2.Location = new System.Drawing.Point(107, 254);
            this.lbl_measure2.Name = "lbl_measure2";
            this.lbl_measure2.Size = new System.Drawing.Size(0, 13);
            this.lbl_measure2.TabIndex = 13;
            // 
            // lbl_measure3
            // 
            this.lbl_measure3.AutoSize = true;
            this.lbl_measure3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_measure3.Location = new System.Drawing.Point(107, 273);
            this.lbl_measure3.Name = "lbl_measure3";
            this.lbl_measure3.Size = new System.Drawing.Size(0, 13);
            this.lbl_measure3.TabIndex = 14;
            // 
            // lbl_measure4
            // 
            this.lbl_measure4.AutoSize = true;
            this.lbl_measure4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_measure4.Location = new System.Drawing.Point(107, 291);
            this.lbl_measure4.Name = "lbl_measure4";
            this.lbl_measure4.Size = new System.Drawing.Size(0, 13);
            this.lbl_measure4.TabIndex = 15;
            // 
            // lbl_measure5
            // 
            this.lbl_measure5.AutoSize = true;
            this.lbl_measure5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_measure5.Location = new System.Drawing.Point(107, 308);
            this.lbl_measure5.Name = "lbl_measure5";
            this.lbl_measure5.Size = new System.Drawing.Size(0, 13);
            this.lbl_measure5.TabIndex = 16;
            // 
            // lbl_measure6
            // 
            this.lbl_measure6.AutoSize = true;
            this.lbl_measure6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_measure6.Location = new System.Drawing.Point(108, 326);
            this.lbl_measure6.Name = "lbl_measure6";
            this.lbl_measure6.Size = new System.Drawing.Size(0, 13);
            this.lbl_measure6.TabIndex = 17;
            // 
            // btn_clear
            // 
            this.btn_clear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_clear.Location = new System.Drawing.Point(221, 59);
            this.btn_clear.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(63, 26);
            this.btn_clear.TabIndex = 18;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(441, 587);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.lbl_measure6);
            this.Controls.Add(this.lbl_measure5);
            this.Controls.Add(this.lbl_measure4);
            this.Controls.Add(this.lbl_measure3);
            this.Controls.Add(this.lbl_measure2);
            this.Controls.Add(this.lbl_measure1);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.lst_converts);
            this.Controls.Add(this.lst_Inputs);
            this.Controls.Add(this.txt_Input);
            this.Controls.Add(this.btn_K_TO_Miles);
            this.Controls.Add(this.btn_C_TO_Feet);
            this.Controls.Add(this.btn_C_To_Fahrenheit);
            this.Controls.Add(this.btn_M_TO_Feet);
            this.Controls.Add(this.btn_C_TO_Inches);
            this.Controls.Add(this.btn_Exit);
            this.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_C_TO_Inches;
        private System.Windows.Forms.Button btn_M_TO_Feet;
        private System.Windows.Forms.Button btn_C_To_Fahrenheit;
        private System.Windows.Forms.Button btn_C_TO_Feet;
        private System.Windows.Forms.Button btn_K_TO_Miles;
        private System.Windows.Forms.TextBox txt_Input;
        private System.Windows.Forms.ListBox lst_Inputs;
        private System.Windows.Forms.ListBox lst_converts;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lbl_measure1;
        private System.Windows.Forms.Label lbl_measure2;
        private System.Windows.Forms.Label lbl_measure3;
        private System.Windows.Forms.Label lbl_measure4;
        private System.Windows.Forms.Label lbl_measure5;
        private System.Windows.Forms.Label lbl_measure6;
        private System.Windows.Forms.Button btn_clear;
    }
}

